﻿import { willCore, url, route, layout } from "./willCore/WillCore.js";

willCore("/");